<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mail\DemoMail;
// use App\Http\Controllers\Mail ; 

class MailController extends Controller
{
    //
    // public function index (){
    // 	return view('join');
    // }

    public function send (Request $r){

    	// $email = Auth::user()->email;
        \Mail::to("mahmouddief0@gmail.com")->send(new DemoMail());
        return view('welcome');
    }

}
