<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    
    public function index (){
        return view('admin.adminpanel');
    }
    public function create_admin(Request $request){
        
    }
    public function login (Request $request){
        
        if($request->isMethod('post')){

            $name = $request->name ;
            $password= $request->password; 

            $users = DB::table('admins')->where([['name',$name] ,['password',$password]])->get();
            if(isset($users)){
                session(['registered' => 'ok']);
                return view('admin.adminpanel');
            }
        }

        return view('admin.admin_login'); 
    }

    
    
    public function admin_logout (Request $request){
        $request->session()->flush();
        $request->session()->forget('registered');
        // dd(sesion('registered'));
        return view('admin.admin_login'); 

    }
    
}
