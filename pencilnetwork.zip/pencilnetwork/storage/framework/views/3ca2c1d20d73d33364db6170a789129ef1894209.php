<?php if(Session::get('registered')): ?>
    return  view('admin.adminpanel');
<?php endif; ?>
<form method ='post' action = '<?php echo e(route("adminpanel")); ?>'>
    <?php echo e(csrf_field()); ?>

    <input type = 'text' name = 'name'>
    <input type = 'text' name = 'password'>
    <input type = 'submit' >
</form>