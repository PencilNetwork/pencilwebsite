<div class="col-lg-8 col-md-12 bg-white my-5 py-5">
    <form action = "<?php echo e(route('send')); ?>"  method = 'post' class="container w-75 rounded-0 border-left-md">
      <div class="text-left mb-4 pl-4"> 
         <h2 class="d-inline-block moon-light-font font-3">pencil us</h2>
      </div>
      <?php echo e(csrf_field()); ?>


     <!--  <div class="form-row pl-4">
        <div class="form-group col-md-6">
          <input type="name" class="form-control rounded-0 " style="border-color: #efefef" placeholder="NAME....">
        </div>
        <div class="form-group col-md-6">
          <input type="mobile-no" class="form-control rounded-0" style="border-color: #efefef" placeholder="MOBILE NO....">
        </div>
      </div>
      <div class="form-group mb-4 mt-4 pl-4">
          <input type="email" class="form-control rounded-0" style="border-color: #efefef" placeholder="EMAIL...">
      </div>
     <div class="form-row mb-4 pt-4 pl-4">
        <div class="form-group col-md-6">
           <input type="text" class="form-control rounded-0" placeholder="COMPANY...." style="border-color: #efefef">
        </div> -->
        <div class="form-group col-md-6 pl-4">
          <input type="text" class="form-control rounded-0" placeholder="TITLE...." style="border-color: #efefef">
        </div>
      </div>    
      
      <div class="input-group mb-3 pl-4">
          <div class="input-group-prepend">
          </div>
          <textarea class="form-control rounded-0" aria-label="With textarea" style="border-color: #efefef;" placeholder="REQUIREMENTS...."></textarea>
        </div>

        <input type ='submit' > 
     <!-- <button type="submit" class="btn btn-secondary text-white mt-3 px-5 rounded-0 ml-4" style="font-size: 1.2rem;">Send</button> -->
    </form>
</div>


