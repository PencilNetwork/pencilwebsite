{{-- @if(empty(Session::get('registered')))
return  view('admin.adminpanel');

@endif --}}

{{-- <a href ="{{route('admin_logout')}}" >logout </a>  --}}
adminpanel

<li><a href="{{ route('create_admin') }}">Register</a></li>
<ul class="dropdown-menu">
    <li>
        <a href="{{ route('logout') }}"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
            Logout
        </a>

        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            {{ csrf_field() }}
        </form>
    </li>
</ul>



