@if(Session::get('registered'))
    return  view('admin.adminpanel');
@endif
<form method ='post' action = '{{route("adminpanel")}}'>
    {{csrf_field()}}
    <input type = 'text' name = 'name'>
    <input type = 'text' name = 'password'>
    <input type = 'submit' >
</form>