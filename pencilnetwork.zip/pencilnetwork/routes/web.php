<?php


Route::get('/', function () {
    return view('join');
});


// Route::get('/join','MailController@index')->name('join');
Route::post('join/send','MailController@send')->name('send');
// Route::match(['get', 'post'],'/adminpanel','AdminController@login')->name('adminpanel');
// Route::get('admin_logout','AdminController@admin_logout')->name('admin_logout');
Route::get('/adminpanel','AdminController@index')->name('adminpanel')->middleware('auth');


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
